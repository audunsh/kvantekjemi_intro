"""Particle viewer for bubblebox under Pyodide.

Desktop sessions keep Evince. This widget only has to accept the same
``pos`` assignment that ``mdbox.update_evince`` already performs.
"""

import pathlib

_ESM_PATH = pathlib.Path(__file__).resolve().parent / "static" / "particles.js"


def make_particle_view(pos, colors, radius):
    try:
        import anywidget
        import traitlets
    except ImportError as exc:
        raise ImportError(
            "anywidget is required to draw bubblebox in JupyterLite. "
            "Install it with: pip install anywidget"
        ) from exc

    if not _ESM_PATH.is_file():
        raise FileNotFoundError(
            "Missing bundled particle viewer at %s. "
            "Rebuild it with: npm run build --prefix bubblebox/js" % _ESM_PATH
        )

    class ParticleView(anywidget.AnyWidget):
        _esm = _ESM_PATH
        pos = traitlets.List([]).tag(sync=True)
        colors = traitlets.List([]).tag(sync=True)
        radius = traitlets.Float(0.2).tag(sync=True)

    view = ParticleView()
    view.pos = pos
    view.colors = colors
    view.radius = float(radius)
    return view
